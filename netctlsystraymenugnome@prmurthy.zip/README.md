netctlsystraymenugnome
======================

This is a gnome applet to display netctl status and switch netctl profiles

This version works with Gnome Shell 3.12. It may work with older versions - YMMV.
The code in extension.js has some comments which may help you make it work with older gnome versions

ARCHLINUX
To install on Arch, use the associated aur package

Others
Download zip file
mkdir ~/.local/share/gnome-shell/extensions/netctlsystraymenugnome@prmurthy
cd ~/.local/share/gnome-shell/extensions/netctlsystraymenugnome@prmurthy
unzip <path to the file you downloaded>

You should now be able to enable it using gnome-tweak-tool, or gsettings
